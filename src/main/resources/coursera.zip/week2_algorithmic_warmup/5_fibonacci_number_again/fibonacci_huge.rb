#!/usr/bin/env ruby
# by Andronik Ordian

def fib_huge(n, m)
  # fix me
  0
end

if __FILE__ == $0
  a, b = gets.split().map(&:to_i)
  puts "#{fib_huge(a, b)}"
end